# IPTV Scanner — Android

Mali Android projekt za ručnu provjeru servera i M3U/M3U8 URL-a.

## Funkcije
- ručni unos URL-a servera
- HTTP status i vrijeme odziva
- opcionalna provjera M3U/M3U8 URL-a
- broj `#EXTINF` stavki pronađenih u prvih 5000 redaka
- izvoz izvještaja u tekstualnu datoteku

## Izrada APK-a
1. Instaliraj Android Studio i Android SDK (API 35).
2. Otvori mapu `IPTVScannerAndroid` u Android Studiju.
3. Pričekaj Gradle sync.
4. Odaberi **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK će se pojaviti u `app/build/outputs/apk/debug/app-debug.apk`.

## Napomene
- Projekt zahtijeva Android Gradle Plugin 8.7.3 i kompatibilnu Gradle 8.9 instalaciju koju Android Studio može preuzeti.
- Za HTTP URL-ove je omogućena cleartext podrška jer neki testni serveri ne koriste HTTPS. Unosi samo pouzdane URL-ove.
- Status HTTP endpointa ne potvrđuje da će se svi video streamovi reproducirati.
- Testiraj samo servere i playliste za koje imaš ovlaštenje.
