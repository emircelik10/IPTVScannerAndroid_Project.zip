package com.example.iptvscanner;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import android.content.Intent;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private EditText serverInput, playlistInput;
    private TextView statusText, latencyText, playlistText, logText;
    private Button scanButton, exportButton;
    private String latestReport = "IPTV Scanner report\nNo scan performed yet.\n";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(15, 23, 42));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("IPTV SCANNER");
        title.setTextSize(25);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Provjera servera i M3U/M3U8 liste");
        subtitle.setTextColor(Color.rgb(148, 163, 184));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(4), 0, dp(20));
        root.addView(subtitle);

        addLabel(root, "URL servera (npr. https://example.com:8080)");
        serverInput = addInput(root, "https://");
        addLabel(root, "URL M3U/M3U8 liste (opcionalno)");
        playlistInput = addInput(root, "https://example.com/playlist.m3u");

        scanButton = new Button(this);
        scanButton.setText("SKENIRAJ SERVER");
        root.addView(scanButton, matchWrap());
        scanButton.setOnClickListener(v -> scan());

        statusText = resultCard(root, "Status: —");
        latencyText = resultCard(root, "Vrijeme odziva: —");
        playlistText = resultCard(root, "M3U lista: nije provjerena");

        addLabel(root, "Dnevnik");
        logText = new TextView(this);
        logText.setTextColor(Color.rgb(203, 213, 225));
        logText.setTextSize(13);
        logText.setText("Unesi server i pokreni skeniranje.");
        logText.setPadding(dp(12), dp(12), dp(12), dp(12));
        logText.setBackgroundColor(Color.rgb(30, 41, 59));
        root.addView(logText, matchWrap());

        exportButton = new Button(this);
        exportButton.setText("IZVEZI REZULTATE (.TXT)");
        root.addView(exportButton, matchWrap());
        exportButton.setOnClickListener(v -> exportReport());

        TextView note = new TextView(this);
        note.setText("Koristi samo servere i liste za koje imaš dozvolu. HTTP provjere mogu slati zahtjeve na uneseni URL.");
        note.setTextColor(Color.rgb(148, 163, 184));
        note.setTextSize(12);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void addLabel(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.rgb(226, 232, 240));
        t.setTextSize(14);
        t.setPadding(0, dp(10), 0, dp(6));
        root.addView(t);
    }

    private EditText addInput(LinearLayout root, String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setHint(hint);
        e.setHintTextColor(Color.GRAY);
        e.setTextColor(Color.WHITE);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(56, 189, 248)));
        root.addView(e, matchWrap());
        return e;
    }

    private TextView resultCard(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(10);
        t.setBackgroundColor(Color.rgb(30, 41, 59));
        root.addView(t, lp);
        return t;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void scan() {
        final String server = serverInput.getText().toString().trim();
        final String playlist = playlistInput.getText().toString().trim();
        if (server.isEmpty() || !(server.startsWith("http://") || server.startsWith("https://"))) {
            Toast.makeText(this, "Unesi ispravan URL servera koji počinje s http:// ili https://", Toast.LENGTH_LONG).show();
            return;
        }
        scanButton.setEnabled(false);
        statusText.setText("Status: provjera...");
        latencyText.setText("Vrijeme odziva: mjeri se...");
        playlistText.setText("M3U lista: provjera...");
        logText.setText("Pokrenuta provjera...");
        new Thread(() -> {
            StringBuilder report = new StringBuilder("IPTV Scanner report\n");
            report.append("Server: ").append(server).append("\n");
            Check serverCheck = checkUrl(server, false);
            report.append("Server status: ").append(serverCheck.ok ? "ONLINE" : "OFFLINE / ERROR").append("\n");
            report.append("HTTP code: ").append(serverCheck.code).append("\n");
            report.append("Latency: ").append(serverCheck.ms >= 0 ? serverCheck.ms + " ms" : "N/A").append("\n");

            Check listCheck = null;
            if (!playlist.isEmpty()) {
                report.append("Playlist: ").append(playlist).append("\n");
                listCheck = checkUrl(playlist, true);
                report.append("Playlist status: ").append(listCheck.ok ? "ACCESSIBLE" : "UNAVAILABLE / ERROR").append("\n");
                report.append("Playlist HTTP code: ").append(listCheck.code).append("\n");
                report.append("M3U entries detected: ").append(listCheck.entries).append("\n");
                report.append("Playlist detail: ").append(listCheck.detail).append("\n");
            } else {
                report.append("Playlist: not provided\n");
            }
            report.append("Note: HTTP reachability does not guarantee playback of every stream.\n");
            final String finalReport = report.toString();
            runOnUiThread(() -> {
                latestReport = finalReport;
                statusText.setText("Status: " + (serverCheck.ok ? "ONLINE" : "OFFLINE / ERROR") +
                        (serverCheck.code > 0 ? " (HTTP " + serverCheck.code + ")" : ""));
                latencyText.setText("Vrijeme odziva: " + (serverCheck.ms >= 0 ? serverCheck.ms + " ms" : "N/A"));
                if (listCheck == null) {
                    playlistText.setText("M3U lista: nije unesena");
                } else {
                    playlistText.setText("M3U lista: " + (listCheck.ok ? "dostupna" : "nedostupna") +
                            " · stavke: " + listCheck.entries);
                }
                logText.setText(finalReport);
                scanButton.setEnabled(true);
            });
        }).start();
    }

    private static class Check {
        boolean ok; int code = -1; long ms = -1; int entries = 0; String detail = "";
    }

    private Check checkUrl(String address, boolean readPlaylist) {
        Check c = new Check();
        HttpURLConnection conn = null;
        long start = System.currentTimeMillis();
        try {
            URL url = new URL(address);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(7000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "IPTVScanner-Android/1.0");
            conn.setInstanceFollowRedirects(true);
            conn.connect();
            c.code = conn.getResponseCode();
            c.ms = System.currentTimeMillis() - start;
            c.ok = c.code >= 200 && c.code < 400;
            if (readPlaylist && c.ok) {
                InputStream in = c.code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                if (in != null) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                    String line; int lines = 0; int entries = 0; StringBuilder sample = new StringBuilder();
                    while ((line = br.readLine()) != null && lines < 5000) {
                        lines++;
                        String trimmed = line.trim();
                        if (trimmed.startsWith("#EXTINF")) entries++;
                        if (sample.length() < 240 && !trimmed.isEmpty()) sample.append(trimmed).append(" ");
                    }
                    br.close();
                    c.entries = entries;
                    c.detail = "Pročitano do " + lines + " redaka";
                    if (entries == 0) c.detail += "; nije pronađen #EXTINF";
                }
            }
        } catch (Exception e) {
            c.detail = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
        return c;
    }

    private void exportReport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "iptv-scan-report.txt");
        startActivityForResult(intent, 42);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 42 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(latestReport.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Rezultati su izvezeni.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Izvoz nije uspio: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
